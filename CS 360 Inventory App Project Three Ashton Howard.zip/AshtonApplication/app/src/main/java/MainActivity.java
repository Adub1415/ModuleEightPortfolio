package com.example.inventorycontrolapplication;

import android.os.Bundle;

import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;

    @Override
    proetected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.Layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setsupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);

        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_settings, R.id.nav_help)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.Menu menu);
        return true;
    }
    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                super.onSupportNavigateUp();
    }
}

@Override
public void onCreate(Bundle savedInstanceState) {
super.onCreate(savedINstanceState);
setContentView(R.layout.activity_login);
loginModel = new ViewModelProvider(this, new LoginModel(getApplicationContext()))
        .get(LoginModel.class);

final EditText usernameEditText = findViewById(R.id.username);
final EditText passwordEditText = findViewById(R.id.password);
final Button loginButton = findViewById(R.id.login);
final Button registerButton = findViewById(R.id.register);
final ProgressBar loadingProgressBar = findViewById(R.id.laoding);

loginModel.getLoginFormState().observe(this, new Observer<LoginFormState>() {
    @Override
    public void onChanged(@Nullable LoginFormState loginFormState) {
        if (loginFormState == null) {
            return;
        }
        loginButton.setEnabled(loginFormState.isDataValid());
        registerButton.setEnabled(loginFormState.isDataValid());
        if (loginFormState.getUsernameError() !=null) {
            usernameEditText.setError(getString(loginFormState.getUsernameError()));
        }
        if(loginFormState.getPasswordError() !=null) {
            passwordEditText.setError(getString(loginFormState.getPasswordError()));
        }
    }
});
loginModel.getLoginResult().observe(this, new Observer<LoginResult>() {
    @Override
    public void onChanged(@Nullable LoginResult loginResult) {
        if (loginResult == null) {
            return;
        }
        laodingProgressBar.setVisibility(View.GONE);
        if (loginResult.getError() !=null) {
            showLoginFailed(loginResult.getError());
        }
        if (loginResult.getSuccess() !=null) {
            updateUiWithUser(loginResult.getSuccess());
        }
        setResult(Activity.RESULT_OK);

        finish;
    }
});

TextWatcher afterTextChangedListener = new TextWatcher() {
    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }
    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }
    @Override
    public void afterTextChanged(Editable s) {
        loginModel.loginDataChanged(usernameEditText.getText().toString(),
                passwordEditText.getText().toString());
    }
};
usernameEditText.addTextChangedListener(afterTextChangedListener);
passwordEditText.addTextChangedListener(afterTextChangedListener);
passwordEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_DONE) {
            loginModel.login(usernameEditText.getText().toString()),
            passwordEditText.getText().toString());
        }
        return false;
    }
});
loginButton.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View v)
    loadingProgressBar.setVisibility(View.VISIBLE);
    loginModel.login(usernameEditText.getText().toString(),
        passwordEditText.getText().tostring());
}
});
registerButton.setOnClickListener(new View.OnClickListener() {
    @Override
            public void onClick(View v) {
        loadingProgressBar.setVisibility(View.VISIBLE);
        loginModel.register(usernameEditText.getText().toString(),
                passwordEditText.getText().toString());
    }
});
private void updateUiWithUser(LoggedInUserView model) {
    String welcome = getString(R.string.welcome) + model.getDisplayName();
    Intent intent = new Intent(this, MainActivity.class);
    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAT_ACTIVITY_NEW_TASK);
    intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
    startActivity(intent);

    Toast.makeText(getApplicationContext(), welcome, Toast.LENGTH_LONG). show();

    private void showLoginFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }
}
public class InventoryDataSource {
    private SqlDbHelper DbHelper;

    public InventoryDataSource (Context context) {
        DbHelper = new SqlDbHelper(context);
    }
    public Cursor queryInventoryDatabase(String[] projection, @Nullable String selection,
                                         @Nullable String[] selectionArgs, @Nullable String sortOrder) {
       SQLiteDatabase db = DbHelper.getReadableDatabase();

       return db.query(
               SqlDbContract.InventoryEntry.TABLE_NAME,
               projection,
               selection,
               selectionArgs,
               null,
               null,
               sortOrder
       );
    }
    public long insertInventoryDatabase(String productName, String productType, String productCount) {
        SQLiteDatabase db = DbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(SqlDbContract.InventoryEntry.COLUMN_NAME_NAME, productName);
        values.put(SqlDbContract.InventoryEntry.COLUMN_NAME_TYPE, productType);
        values.put(SqlDbContract.InventoryEntry.COLUMN_NAME_COUNT, productCount);
        values.put(SqlDbContract.InventoryEntry.COLUMN_NAME_DATE, java.text.DateFormat.getDateTimeInstance().format(new Date()));

        return db.insert(SqlDbContract.InventoryEntry.TABLE_NAME, null, values);
    }
    public boolean updateInventoryDatabase(String productId, String newCount) {
        SQLiteDatabase db = DbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(SqlDbContract.InventoryEntry.COLUMN_NAME_COUNT, newCount);
        String selection = SqlDbContract.InventoryEntry_ID + " LIKE ?";
        String[] selectionArgs = {productId};
        return db.update(
                SqlDbContract.InventoryEntry.TABLE_NAME,
                values,
                selection,
                selectionArgs) > 0;
    }
    public boolean deleteInventoryDatabase(String productId) {
        SQLiteDatabase db = DbHelper.getWritableDatabase();
        String selection = SqlDbContract.InventoryEntry_ID + " LIKE ?";
        String[] selectionArgs = { productID };
        return db.delete{
            SqlDbContract.InventoryEntry.TABLE_NAME,
            selection,
            selectionArgs) > 0;
        }
        public boolean deleteAllInventoryData() {
            SQLiteDatabase db = DbHelper.getWriteableDatabase();
            return db.delete(
                    SqlDbContract.InventoryEntry.TABLE_NAME,
                    null,
                    null) > 0;
            )
        }
    }
}
public class NotiicationTimer {
    private Context context;
    private Timer timer;

    public NotificationTimer(Context context)
    {
        this.timer = new Timer();
        this.context = context;
    }
    private class Work extends TimerTask
    {
        private Context context;
        InventoryDataSource dataSource;

        public Work(Context context) {
            this.context = context;
            this.dataSource = new InventoryDataSource(this.context);
        }
        public void run()
        {
            String[] projection = {
                    BaseColumns_ID,
                    SqlDbContract.InventoryEntry.COLUMN_NAME_NAME,
                    SqlDbContract.InventoryEntry.COLUMN_NAME_TYPE,
                    SqlDbContract.InventoryEntry.COLUMN_NAME_COUNT
            };
            String selection = SqlDbContract.InventoryEntry.COLUMN_NAME_COUNT + " < ?";
            String[] selectionArgs = { "5" };

            Cursor cursor = dataSource.queryInventoryDatabase(projection, selection, selectionArgs, null);
            for (HashMap row : SqlDbHelper.GetAll(cursor)) {
                String productName = row.get(SqlDbContract.InventoryEntry.COLUMN_NAME_NAME).toString();
                String productCount = row.get(SqlDbContract.InventoryEntry.COLUMN_NAME_COUNT).toString():
                String phoneNumber = null;

                if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                    TelephonyManager telephonyManager = (TelephonyManager)context.getSystemService(context.TELEPHONY_SERVICE);
                    phoneNumber = telephonyManager.getLine1Number();
                }
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNumber, null, "Item " + productName + " has a low count of " + productCount + " .", null, null);
                }
            }
        }
    }
    public void StartThread() {
        timer.scheduleAtFixedRate(new Work(this.context), 0, 60000);
    }
    public void StopThread() {
        timer.cancel();
    }
}